package com.neverless.domain;

import java.util.UUID;

public interface Account {
    AccountId id();
}
